//Christian Wunder
//22.02.2022
//Encrypter

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <conioex.h>

char encryptCaesar(char plainChar, int key);
char encryptAtbash(char plainChar);
void encryptRot13(char plainChar,char *cipherChar);
char chartoint(char plainChar);

int main()
{
    int key=5;
    int i=2, j=2, k=2;
    int i2=4, j2=6, k2=8;
    char plainChar=0, rot=0;
    system("cls");
    printf(" Text zu Caesar,Atbash,Rot13");
    gotoxy(i,i2);
    do
    {
        plainChar=getch();
        switch (plainChar)
        {
        case 'a':
            plainChar=97;
            break;
        
        case 'b':
            plainChar=98;
            break;

        case 'c':
            plainChar=99;
            break;

        case 'd':
            plainChar=100;
            break;
        
        case 'e':
            plainChar=101;
            break;

        case 'f':
            plainChar=102;
            break;

        case 'g':
            plainChar=103;
            break;

        case 'h':
            plainChar=104;
            break;

        case 'i':
            plainChar=105;
            break;

        case 'j':
            plainChar=106;
            break;

        case 'k':
            plainChar=107;
            break;

        case 'l':
            plainChar=108;
            break;
        
        case 'm':
            plainChar=109;
            break;
        
        case 'n':
            plainChar=110;
            break;
        
        case 'o':
            plainChar=111;
            break;
        
        case 'p':
            plainChar=112;
            break;
        
        case 'q':
            plainChar=113;
            break;
        
        case 'r':
            plainChar=114;
            break;
        
        case 's':
            plainChar=115;
            break;
        
        case 't':
            plainChar=116;
            break;
        
        case 'u':
            plainChar=117;
            break;
        
        case 'v':
            plainChar=118;
            break;
        
        case 'w':
            plainChar=119;
            break;
        
        case 'x':
            plainChar=120;
            break;
        
        case 'y':
            plainChar=121;
            break;
        
        case 'z':
            plainChar=122;
            break;
        default:
            break;
        }
        if (i!=170||j!=170||k!=170)
        {
            gotoxy(i,i2);
            textcolor(RED);
            printf("%c",encryptCaesar(plainChar,key));
            i++;
            gotoxy(j,j2);
            textcolor(GREEN);
            printf("%c",encryptAtbash(plainChar));
            j++;
            gotoxy(k,k2);
            textcolor(BLUE);
            encryptRot13(plainChar,&rot);
            printf("%c",rot);
            k++;
        }
    } while (plainChar!=13);
    
    
    return EXIT_SUCCESS;
}

char encryptCaesar(char plainChar, int key)
{
    int res=0, tempkey=0;
    res=plainChar+key;
    if (res>122)
    {
        tempkey=res-122;
        res=96+tempkey;
    }
    return res;
}

char encryptAtbash(char plainChar)
{
    int res=0;

    res=122-(plainChar-97);
    return res;
}

void encryptRot13(char plainChar,char *cipherChar)
{
    int res=0, tempkey=0, key=13;
    res=plainChar+key;
    if (res>122)
    {
        tempkey=res-122;
        res=96+tempkey;
    }
    *cipherChar = res;
}

